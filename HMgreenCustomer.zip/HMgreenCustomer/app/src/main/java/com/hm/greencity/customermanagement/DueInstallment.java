package com.hm.greencity.customermanagement;

import android.app.DatePickerDialog;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import android.os.Bundle;
import androidx.recyclerview.widget.RecyclerView;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;

import com.google.gson.JsonObject;
import com.hm.greencity.customermanagement.adapters.AdapterDueInstallment;
import com.hm.greencity.customermanagement.common.Utils;
import com.hm.greencity.customermanagement.models.DueInstallment.ResponseDueInstallment;
import com.hm.greencity.customermanagement.models.ResponseList.LstBlock;
import com.hm.greencity.customermanagement.models.ResponseList.LstPhase;
import com.hm.greencity.customermanagement.models.ResponseList.LstSite;
import com.hm.greencity.customermanagement.common.BaseActivity;
import com.hm.greencity.customermanagement.common.NetworkUtils;
import com.hm.greencity.customermanagement.common.PreferencesManager;
import com.hm.greencity.customermanagement.models.ResponseList.ResponseSite;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import butterknife.BindView;
import butterknife.OnClick;
import butterknife.Unbinder;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DueInstallment extends BaseActivity {


    @BindView(R.id.btn_search)
    ImageView btnSearch;
    @BindView(R.id.recyclerview1)
    RecyclerView recyclerview1;
    Unbinder unbinder;
    private BottomSheetDialog bottomSheetDialog;
    TextView tvStartDate;
    TextView tvEndDate;
    TextView tvSelectSite;
    TextView tvSector;
    TextView selectBlock;
    EditText etBookingNumber;
    EditText etPlotNumber;
    private List<LstSite> lstsites;
    private List<LstPhase> lstSectors;
    private List<LstBlock> lstBlocks;
    private ArrayList<String> SelectSite, SelectSector, SelectBlock;
    private String PK_SectorID, PK_SiteID, PK_BlockID;
    private PopupMenu sitemenu, sectorMenu, blockMenu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_due_installment);

        recyclerview1.setHasFixedSize(true);
//        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getContext());
//        recyclerview1.setLayoutManager(layoutManager);

        if (NetworkUtils.getConnectivityStatus(context) != 0)
            getData();
        else showMessage(R.string.alert_internet);
    }


    public void getData() {
        showLoading();
        JsonObject object = new JsonObject();
        object.addProperty("LoginId", PreferencesManager.getInstance(context).getLoginId());
//        LoggerUtil.logItem(object);
        Call<ResponseDueInstallment> call = apiServices.Dueinstalmentlist(object);
        call.enqueue(new Callback<ResponseDueInstallment>() {
            @Override
            public void onResponse(Call<ResponseDueInstallment> call, Response<ResponseDueInstallment> response) {
                hideLoading();
//                LoggerUtil.logItem(response.body());
                if (response.body().getStatusCode().equalsIgnoreCase("200")) {
                    AdapterDueInstallment adapter = new AdapterDueInstallment(response.body().getLstduelist(), context);
                    recyclerview1.setAdapter(adapter);
                } else showMessage(response.body().getMessage());
            }

            @Override
            public void onFailure(Call<ResponseDueInstallment> call, Throwable t) {
                hideLoading();
            }

        });
    }

    public void getSearchData(String siteid, String sectorid, String blockid, String booking, String plotid, String start, String end) {
        showLoading();
        JsonObject object = new JsonObject();
        //  object.addProperty("LoginId", PreferencesManager.getInstance(context).getLoginId());
        object.addProperty("CustomerID", PreferencesManager.getInstance(context).getUserId());
        object.addProperty("FromDate", start);
        object.addProperty("ToDate", end);
        object.addProperty("SiteID", siteid);

        object.addProperty("PhaseID", sectorid);
        object.addProperty("BlockID", blockid);
        object.addProperty("BookingNumber", booking);
        object.addProperty("PlotNumber", plotid);

//        LoggerUtil.logItem(object);
        Call<ResponseDueInstallment> call = apiServices.Dueinstalmentlist(object);
        call.enqueue(new Callback<ResponseDueInstallment>() {
            @Override
            public void onResponse(Call<ResponseDueInstallment> call, Response<ResponseDueInstallment> response) {
                hideLoading();
//                LoggerUtil.logItem(response.body());
                if (response.body().getStatusCode().equalsIgnoreCase("200")) {
                    AdapterDueInstallment adapter = new AdapterDueInstallment(response.body().getLstduelist(), context);
                    recyclerview1.setAdapter(adapter);
                } else showMessage(response.body().getMessage());
            }

            @Override
            public void onFailure(Call<ResponseDueInstallment> call, Throwable t) {
                hideLoading();
            }

        });
    }


    @OnClick(R.id.btn_search)
    public void onClick() {
        searchhDialog();
    }

    private void searchhDialog() {
        bottomSheetDialog = new BottomSheetDialog(context);
        View sheetView = context.getLayoutInflater().inflate(R.layout.dialog_duinstallment, null);
        bottomSheetDialog.setContentView(sheetView);
        tvStartDate = sheetView.findViewById(R.id.tv_start_date);
        tvEndDate = sheetView.findViewById(R.id.tv_end_date);
        tvSelectSite = sheetView.findViewById(R.id.tv_select_site);
        tvSector = sheetView.findViewById(R.id.tv_sector);
        selectBlock = sheetView.findViewById(R.id.select_block);
        etBookingNumber = sheetView.findViewById(R.id.et_booking_number);
        etPlotNumber = sheetView.findViewById(R.id.et_plot_number);
        Button btnCancel = sheetView.findViewById(R.id.btn_cancel);
        Button btnSearch1 = sheetView.findViewById(R.id.btn_search);
        sitemenu = new PopupMenu(context, tvSelectSite);
        sectorMenu = new PopupMenu(context, tvSector);
        blockMenu = new PopupMenu(context, selectBlock);


        getProductLst();        //  getSector();
        //  getBlock();
        lstsites = new ArrayList<>();
        lstSectors = new ArrayList<>();
        lstBlocks = new ArrayList<>();


        //  SelectSite = new ArrayList<String>();
        //  SelectSector = new ArrayList<String>();
        // SelectBlock = new ArrayList<String>();
        // SelectSiteType=new ArrayList<String>();
        tvSelectSite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sitemenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        int position = item.getOrder();
                        tvSelectSite.setText(lstsites.get(position).getSiteName());
                        PK_SiteID = lstsites.get(position).getSiteID();


                        //  getSector();
                        //  packageMenu = lstPackages.get(position).getProductName();
                        return true;
                    }
                });
                sitemenu.show();
            }
        });
        tvSector.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                sectorMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        int position = item.getOrder();
                        tvSector.setText(lstSectors.get(position).getPhaseName());
                        PK_SectorID = lstSectors.get(position).getPhaseID();

                        //  packageMenu = lstPackages.get(position).getProductName();
                        return true;
                    }
                });
                sectorMenu.show();

            }


        });

        selectBlock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                blockMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        int position = item.getOrder();
                        selectBlock.setText(lstBlocks.get(position).getBlockName());
                        PK_BlockID = lstBlocks.get(position).getBlockID();

                        //  packageMenu = lstPackages.get(position).getProductName();
                        return true;
                    }
                });
                blockMenu.show();
            }
        });

        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bottomSheetDialog.dismiss();
            }
        });
        tvStartDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DueInstallment.this.datePicker(tvStartDate);
                tvEndDate.setText("");
            }
        });

        tvEndDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (tvStartDate.getText().toString().equalsIgnoreCase(""))
                    DueInstallment.this.showMessage("Select Start Date");
                else
                    DueInstallment.this.datePicker(tvEndDate);
            }
        });


        btnSearch1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (tvSelectSite.getText().toString().length() == 0) {
                    DueInstallment.this.showMessage("Select Site");
                } else if (tvSector.getText().toString().length() == 0) {
                    DueInstallment.this.showMessage("Select Phase");
                } else if (selectBlock.getText().toString().length() == 0) {
                    DueInstallment.this.showMessage("Select Block");
                } else {
                    DueInstallment.this.getSearchData(PK_SiteID, PK_SectorID, PK_BlockID, tvStartDate.getText().toString().trim(), tvEndDate.getText().toString().trim(),
                            etBookingNumber.getText().toString().trim(), etBookingNumber.getText().toString().trim());
                    bottomSheetDialog.dismiss();
                }
            }
        });


        bottomSheetDialog.setCancelable(false);
        bottomSheetDialog.setCanceledOnTouchOutside(false);
        bottomSheetDialog.show();
    }

    private void datePicker(final TextView et) {
        Calendar cal = Calendar.getInstance();
        int mYear, mMonth, mDay;

        mYear = cal.get(Calendar.YEAR);
        mMonth = cal.get(Calendar.MONTH);
        mDay = cal.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(context, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                et.setText(Utils.changeDateFormat(dayOfMonth, monthOfYear, year));
            }
        }, mYear, mMonth, mDay);
        datePickerDialog.getDatePicker().setMaxDate(cal.getTimeInMillis());
        datePickerDialog.show();
    }


    public void getProductLst() {
        JsonObject jsonObject = new JsonObject();

        Call<ResponseSite> call = apiServices.sitelist(jsonObject);
        call.enqueue(new Callback<ResponseSite>() {
            @Override
            public void onResponse(Call<ResponseSite> call, Response<ResponseSite> response) {

                hideLoading();
                if (response.body().getStatusCode().equalsIgnoreCase("200")) {
                    lstsites = response.body().getLstSite();
                    lstSectors = response.body().getLstPhase();
                    lstBlocks = response.body().getLstBlock();
                    for (int i = 0; i < lstsites.size(); i++) {
                        sitemenu.getMenu().add(0, 0, i, lstsites.get(i).getSiteName());

                        PK_SiteID = response.body().getLstSite().get(i).getSiteID();


                    }

//                    ----------------------------


                    // Toast.makeText(ReInvestment.this, response+"", Toast.LENGTH_SHORT).show();
                    for (int i = 0; i < lstSectors.size(); i++) {

                        sectorMenu.getMenu().add(0, 0, i, lstSectors.get(i).getPhaseName());

                        PK_SectorID = response.body().getLstPhase().get(i).getPhaseID();

                        // Toast.makeText(context,selectSiteTypeid+ "", Toast.LENGTH_SHORT).show();
                        //  getPackage();

                    }
                    for (int i = 0; i < lstBlocks.size(); i++) {

                        blockMenu.getMenu().add(0, 0, i, lstBlocks.get(i).getBlockName());

                        PK_BlockID = response.body().getLstBlock().get(i).getBlockID();

                        // Toast.makeText(context,selectSiteTypeid+ "", Toast.LENGTH_SHORT).show();
                        //  getPackage();

                    }


                } else
                    showMessage(response.body().getMessage());

            }

            @Override
            public void onFailure(Call<ResponseSite> call, Throwable t) {
                hideLoading();
                // Toast.makeText(ReInvestment.this,t+ "", Toast.LENGTH_SHORT).show();
            }

        });
    }
}