package com.hm.greencity.customermanagement.common.retrofit;

import com.google.gson.JsonObject;
import com.hm.greencity.customermanagement.models.CustomerMyProfile;
import com.hm.greencity.customermanagement.models.DueInstallment.ResponseDueInstallment;
import com.hm.greencity.customermanagement.models.DueInstallmentDashBoard;
import com.hm.greencity.customermanagement.models.HomeActivityDashBoard;
import com.hm.greencity.customermanagement.models.ResponseList.ResponseSite;
import com.hm.greencity.customermanagement.models.ResponseLogin;
import com.hm.greencity.customermanagement.models.UpdateCustomerProfile;
import com.hm.greencity.customermanagement.models.UpdatePassword;


import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;

public interface ApiServices {



    @POST("login")
    Call<ResponseLogin> getLogin(@Body JsonObject login);

    @POST("DashBoard")
    Call<HomeActivityDashBoard> getDashboard(@Body JsonObject dashboard);

     @POST("Dueinstalmentlist")
    Call<DueInstallmentDashBoard> getDueInstallmentDashBoard(@Body JsonObject jsonObject);

    @Multipart
    @POST("api/ImageUpload/user/PostUserImage")
    Call<JsonObject> uploadProfilePic(@Part("fk_UserId") RequestBody fk_UserId,
                                      @Part() MultipartBody.Part file);

    @POST("ProfileDetails")
    Call<CustomerMyProfile> getProfile(@Body JsonObject jsonObject);

    @POST("UpdateProfileDetails")
    Call<UpdateCustomerProfile> updateProfile(@Body JsonObject jsonObject);

    @POST("ChnagePassword")
    Call<UpdatePassword> updatePassword(@Body JsonObject jsonObject);

    @POST("Dueinstalmentlist")
    Call<ResponseDueInstallment>Dueinstalmentlist (@Body JsonObject login);

    @POST("sitelist")
    Call<ResponseSite>sitelist (@Body JsonObject login);
}