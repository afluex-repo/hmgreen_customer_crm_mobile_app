package com.hm.greencity.customermanagement.settings;

public class SettingsService {
}
