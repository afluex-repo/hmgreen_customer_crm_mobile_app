package com.hm.greencity.customermanagement.adapters;

import android.content.Context;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


import com.hm.greencity.customermanagement.R;
import com.hm.greencity.customermanagement.models.DueInstallment.Lstdue;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class AdapterDueInstallment extends RecyclerView.Adapter<AdapterDueInstallment.ViewHolder> {
    private List<Lstdue> models;
    private Context context;

    public AdapterDueInstallment(List<Lstdue> models, Context context) {
        this.models = models;
        this.context = context;
    }



    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.adapter_dueinstallment, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder viewHolder, int i) {

        viewHolder.tvLoginid.setText(models.get(i).getCustomerName() + " (" + models.get(i).getCustomerLoginID() + ")");
        viewHolder.tvPlotDetails.setText(models.get(i).getPlotDetails());
        viewHolder.tvAmount.setText("Amount" + "(" + models.get(i).getInstallmentAmount() + ")");
        viewHolder.InstallmentNo.setText("InstallmentNo" + "(" + models.get(i).getInstallmentNo() + ")");
    }

    @Override
    public int getItemCount() {
        return models.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        @BindView(R.id.tvLoginid)
        TextView tvLoginid;
        @BindView(R.id.tv_plot_details)
        TextView tvPlotDetails;
        @BindView(R.id.InstallmentNo)
        TextView InstallmentNo;
        @BindView(R.id.tvAmount)
        TextView tvAmount;
        @BindView(R.id.card_view)
        CardView cardView;

        public ViewHolder(View view) {
            super(view);
            ButterKnife.bind(this, view);


        }
    }
}